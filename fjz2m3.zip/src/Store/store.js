import { legacy_createStore } from "redux";
import { reducer } from "./Reducer";

export const store = legacy_createStore(reducer);
